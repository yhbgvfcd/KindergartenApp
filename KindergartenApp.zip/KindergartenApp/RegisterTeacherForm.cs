﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KindergartenApp
{
    public partial class RegisterTeacherForm : Form
    {
        public string RegisteredLogin { get; private set; }
        public RegisterTeacherForm()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            UiHelper.SingleLineAll(this);
            UiHelper.MakePassword(txtPassword);

            AcceptButton = btnContinue;

            btnContinue.Click -= btnContinue_Click;
            btnContinue.Click += btnContinue_Click;
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string name = txtName.Text.Trim();
            string surname = txtSurname.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text;

            if (login.Length < 3)
            {
                UiHelper.Warn("Логин должен содержать не менее 3 символов.");
                txtLogin.Focus();
                return;
            }
            if (name.Length == 0)
            {
                UiHelper.Warn("Введите имя.");
                txtName.Focus();
                return;
            }
            if (surname.Length == 0)
            {
                UiHelper.Warn("Введите фамилию.");
                txtSurname.Focus();
                return;
            }
            if (!UiHelper.IsValidEmail(email))
            {
                UiHelper.Warn("Введите корректный адрес электронной почты.");
                txtEmail.Focus();
                return;
            }
            if (password.Length < 6)
            {
                UiHelper.Warn("Пароль должен содержать не менее 6 символов.");
                txtPassword.Focus();
                return;
            }

            var user = new User
            {
                Role = Roles.Teacher,
                Login = login,
                Email = email,
                Name = name,
                Surname = surname,
                ChildName = "",
                ChildSurname = "",
                BirthDate = ""
            };

            string error;
            if (!DataStore.Register(user, password, out error))
            {
                UiHelper.Warn(error);
                return;
            }

            RegisteredLogin = login;
            UiHelper.Info("Регистрация прошла успешно. Теперь войдите в аккаунт.");
            DialogResult = DialogResult.OK;
        }
    }
}
