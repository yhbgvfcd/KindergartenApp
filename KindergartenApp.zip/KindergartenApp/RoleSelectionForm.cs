﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace KindergartenApp
{
    public partial class RoleSelectionForm : Form
    {
        public RoleSelectionForm()
        {
            InitializeComponent();
            btnParent.Click += btnParent_Click_1;
            btnTeacher.Click += btnTeacher_Click;
        }
        
        private void OpenRole(string role)
        {
            Hide();
            try
            {
                using (var login = new LoginForm(role))
                {
                    if (login.ShowDialog() == DialogResult.OK)
                    {
                        using (var main = new MainForm())
                        {
                            main.ShowDialog();
                        }
                    }
                }
            }
            finally
            {
                Session.Current = null;
                Show();
            }
        }

        private void btnParent_Click_1(object sender, EventArgs e)
        {
            OpenRole(Roles.Parent);
        }

        private void btnTeacher_Click(object sender, EventArgs e)
        {
            OpenRole(Roles.Teacher);
        }
    }
}

