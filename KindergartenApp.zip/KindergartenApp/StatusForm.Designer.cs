﻿namespace KindergartenApp
{
    partial class StatusForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAbsent = new System.Windows.Forms.Button();
            this.btnSick = new System.Windows.Forms.Button();
            this.btnWas = new System.Windows.Forms.Button();
            this.lblPrompt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAbsent
            // 
            this.btnAbsent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.btnAbsent.FlatAppearance.BorderSize = 0;
            this.btnAbsent.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnAbsent.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAbsent.Location = new System.Drawing.Point(12, 144);
            this.btnAbsent.Name = "btnAbsent";
            this.btnAbsent.Size = new System.Drawing.Size(276, 36);
            this.btnAbsent.TabIndex = 64;
            this.btnAbsent.Text = "ОТСУТСТВОВАЛ(А)";
            this.btnAbsent.UseVisualStyleBackColor = false;
            // 
            // btnSick
            // 
            this.btnSick.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.btnSick.FlatAppearance.BorderSize = 0;
            this.btnSick.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnSick.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSick.Location = new System.Drawing.Point(12, 102);
            this.btnSick.Name = "btnSick";
            this.btnSick.Size = new System.Drawing.Size(276, 36);
            this.btnSick.TabIndex = 63;
            this.btnSick.Text = "БОЛЕЕТ";
            this.btnSick.UseVisualStyleBackColor = false;
            // 
            // btnWas
            // 
            this.btnWas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(211)))), ((int)(((byte)(114)))));
            this.btnWas.FlatAppearance.BorderSize = 0;
            this.btnWas.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnWas.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnWas.Location = new System.Drawing.Point(12, 60);
            this.btnWas.Name = "btnWas";
            this.btnWas.Size = new System.Drawing.Size(276, 36);
            this.btnWas.TabIndex = 62;
            this.btnWas.Text = "БЫЛ(А)";
            this.btnWas.UseVisualStyleBackColor = false;
            // 
            // lblPrompt
            // 
            this.lblPrompt.AutoSize = true;
            this.lblPrompt.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrompt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.lblPrompt.Location = new System.Drawing.Point(12, 23);
            this.lblPrompt.Name = "lblPrompt";
            this.lblPrompt.Size = new System.Drawing.Size(231, 21);
            this.lblPrompt.TabIndex = 65;
            this.lblPrompt.Text = "СТАТУС ПОСЕЩАЕМОСТИ";
            // 
            // StatusForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(309, 208);
            this.Controls.Add(this.lblPrompt);
            this.Controls.Add(this.btnAbsent);
            this.Controls.Add(this.btnSick);
            this.Controls.Add(this.btnWas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "StatusForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAbsent;
        private System.Windows.Forms.Button btnSick;
        private System.Windows.Forms.Button btnWas;
        private System.Windows.Forms.Label lblPrompt;
    }
}