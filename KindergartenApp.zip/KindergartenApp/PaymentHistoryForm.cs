﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace KindergartenApp
{
    public partial class PaymentHistoryForm : Form
    {
        public PaymentHistoryForm()
        {
            InitializeComponent();
            lstPayments.HorizontalScrollbar = true;
            LoadPayments();
        }
        private void LoadPayments()
        {
            lstPayments.Items.Clear();
            if (Session.Current == null) return;

            List<string> payments = DataStore.GetPayments(Session.Current.Login);
            if (payments.Count == 0)
            {
                lstPayments.Items.Add("История платежей пуста.");
                return;
            }

            foreach (string p in payments)
                lstPayments.Items.Add(p);
        }
    }
}
