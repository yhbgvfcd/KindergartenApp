﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace KindergartenApp
{
    public static class Roles
    {
        public const string Parent = "parent";
        public const string Teacher = "teacher";
    }

    public class User
    {
        public string Role { get; set; }
        public string Login { get; set; }
        public string PasswordHash { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string ChildName { get; set; }
        public string ChildSurname { get; set; }
        public string BirthDate { get; set; }
        public string MedicalNotes { get; set; }

        public string DisplayName
        {
            get
            {
                if (Role == Roles.Parent)
                {
                    string child = ChildFullName;
                    if (child.Length == 0) return Login ?? "";
                    string age = AgeText;
                    return age.Length > 0 ? child + ", " + age : child;
                }

                string n = ((Surname ?? "") + " " + (Name ?? "")).Trim();
                return n.Length > 0 ? n : (Login ?? "");
            }
        }

        public string ChildFullName
        {
            get { return ((ChildSurname ?? "") + " " + (ChildName ?? "")).Trim(); }
        }

        public int Age
        {
            get
            {
                DateTime birth;
                if (!DateTime.TryParse(BirthDate, CultureInfo.InvariantCulture,
                        DateTimeStyles.None, out birth))
                    return -1;

                DateTime today = DateTime.Today;
                int age = today.Year - birth.Year;
                if (birth.Date > today.AddYears(-age)) age--;
                return age < 0 ? -1 : age;
            }
        }

        public string AgeText
        {
            get
            {
                int a = Age;
                if (a < 0) return "";
                if (a == 0) return "меньше года";

                int n100 = a % 100;
                int n10 = a % 10;
                string word;
                if (n100 >= 11 && n100 <= 14) word = "лет";
                else if (n10 == 1) word = "год";
                else if (n10 >= 2 && n10 <= 4) word = "года";
                else word = "лет";
                return a + " " + word;
            }
        }

        private static string B64(string s)
        {
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(s ?? ""));
        }

        private static string FromB64(string s)
        {
            return Encoding.UTF8.GetString(Convert.FromBase64String(s));
        }

        public string Serialize()
        {
            return string.Join(";", new[]
            {
                B64(Role), B64(Login), B64(PasswordHash), B64(Email), B64(Name),
                B64(Surname), B64(ChildName), B64(ChildSurname), B64(BirthDate), B64(MedicalNotes ?? "")
            });
        }

        public static User Parse(string line)
        {
            try
            {
                string[] p = line.Split(';');
                if (p.Length != 9 && p.Length != 10) return null;
                return new User
                {
                    Role = FromB64(p[0]),
                    Login = FromB64(p[1]),
                    PasswordHash = FromB64(p[2]),
                    Email = FromB64(p[3]),
                    Name = FromB64(p[4]),
                    Surname = FromB64(p[5]),
                    ChildName = FromB64(p[6]),
                    ChildSurname = FromB64(p[7]),
                    BirthDate = FromB64(p[8]),
                    MedicalNotes = p.Length >= 10 ? FromB64(p[9]) : ""
                };
            }
            catch (FormatException)
            {
                return null;
            }
        }
    }

    public static class Session
    {
        public static User Current { get; set; }
    }

    public static class DataStore
    {
        public static readonly string[] MonthNames =
        {
            "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
            "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
        };

        private static readonly string Folder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "KindergartenApp");
        private static readonly string UsersFile = Path.Combine(Folder, "users.dat");
        private static readonly string NotificationsFile = Path.Combine(Folder, "notifications.dat");
        private static readonly string ScheduleFile = Path.Combine(Folder, "schedule.dat");
        private static readonly string MarksFile = Path.Combine(Folder, "marks.dat");
        private static readonly string PaymentsFile = Path.Combine(Folder, "payments.dat");

        private static string B64(string s)
        {
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(s ?? ""));
        }

        private static string FromB64(string s)
        {
            return Encoding.UTF8.GetString(Convert.FromBase64String(s));
        }

        public static string DateKey(DateTime d)
        {
            return d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        private static List<string[]> ReadRows(string file)
        {
            var result = new List<string[]>();
            if (!File.Exists(file)) return result;
            foreach (string line in File.ReadAllLines(file, Encoding.UTF8))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                try
                {
                    string[] p = line.Split(';');
                    if (p.Length < 2) continue;
                    var row = new string[p.Length];
                    for (int i = 0; i < p.Length; i++)
                        row[i] = FromB64(p[i]);
                    result.Add(row);
                }
                catch (FormatException)
                {
                }
            }
            return result;
        }

        private static void WriteRows(string file, List<string[]> rows)
        {
            Directory.CreateDirectory(Folder);
            string[] lines = rows
                .Select(r => string.Join(";", r.Select(x => B64(x)).ToArray()))
                .ToArray();
            File.WriteAllLines(file, lines, Encoding.UTF8);
        }

        private static List<User> Load()
        {
            var result = new List<User>();
            if (!File.Exists(UsersFile)) return result;
            foreach (string line in File.ReadAllLines(UsersFile, Encoding.UTF8))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                User u = User.Parse(line);
                if (u != null) result.Add(u);
            }
            return result;
        }

        private static void Save(List<User> users)
        {
            Directory.CreateDirectory(Folder);
            File.WriteAllLines(UsersFile, users.Select(u => u.Serialize()).ToArray(), Encoding.UTF8);
        }

        public static bool Register(User user, string password, out string error)
        {
            error = null;
            try
            {
                List<User> users = Load();
                if (users.Any(u => string.Equals(u.Login, user.Login, StringComparison.OrdinalIgnoreCase)))
                {
                    error = "Пользователь с таким логином уже существует.";
                    return false;
                }
                user.PasswordHash = Hash(password);
                users.Add(user);
                Save(users);
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось сохранить данные: " + ex.Message;
                return false;
            }
        }

        public static User Authenticate(string login, string password, string role)
        {
            try
            {
                User user = Load().FirstOrDefault(u =>
                    string.Equals(u.Login, login, StringComparison.OrdinalIgnoreCase) && u.Role == role);
                if (user == null) return null;
                return Verify(password, user.PasswordHash) ? user : null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static bool ChangePassword(string login, string oldPassword, string newPassword, out string error)
        {
            error = null;
            try
            {
                List<User> users = Load();
                User user = users.FirstOrDefault(u =>
                    string.Equals(u.Login, login, StringComparison.OrdinalIgnoreCase));
                if (user == null)
                {
                    error = "Пользователь не найден.";
                    return false;
                }
                if (!Verify(oldPassword, user.PasswordHash))
                {
                    error = "Текущий пароль указан неверно.";
                    return false;
                }
                user.PasswordHash = Hash(newPassword);
                Save(users);
                if (Session.Current != null &&
                    string.Equals(Session.Current.Login, login, StringComparison.OrdinalIgnoreCase))
                    Session.Current.PasswordHash = user.PasswordHash;
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось сохранить данные: " + ex.Message;
                return false;
            }
        }

        public static List<string> GetChildren()
        {
            try
            {
                return Load()
                    .Where(u => u.Role == Roles.Parent)
                    .Select(u => u.ChildFullName)
                    .Where(n => n.Length > 0)
                    .OrderBy(n => n)
                    .ToList();
            }
            catch (Exception)
            {
                return new List<string>();
            }
        }

        public static List<User> GetParents()
        {
            try
            {
                return Load()
                    .Where(u => u.Role == Roles.Parent)
                    .OrderBy(u => u.ChildFullName)
                    .ToList();
            }
            catch (Exception)
            {
                return new List<User>();
            }
        }

        public static List<string[]> LoadSchedule()
        {
            var result = new List<string[]>();
            for (int i = 0; i < 7; i++)
                result.Add(new[] { "" });

            foreach (string[] r in ReadRows(ScheduleFile))
            {
                int idx;
                if (int.TryParse(r[0], out idx) && idx >= 0 && idx < 7)
                    result[idx] = new[] { r[1] ?? "" };
            }
            return result;
        }

        public static void SaveSchedule(List<string[]> rows)
        {
            var list = new List<string[]>();
            for (int i = 0; i < rows.Count; i++)
            {
                list.Add(new[] { i.ToString(), rows[i][0] ?? "" });
            }
            WriteRows(ScheduleFile, list);
        }

        public static Dictionary<string, string> GetMarks(string childLogin)
        {
            var result = new Dictionary<string, string>();
            foreach (string[] r in ReadRows(MarksFile))
            {
                if (r.Length >= 3 && string.Equals(r[1], childLogin, StringComparison.OrdinalIgnoreCase))
                    result[r[0]] = r[2];
            }
            return result;
        }

        public static void SetMark(DateTime date, string childLogin, string mark)
        {
            string key = DateKey(date);
            List<string[]> rows = ReadRows(MarksFile);
            rows.RemoveAll(r => r.Length >= 2 && r[0] == key &&
                string.Equals(r[1], childLogin, StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrEmpty(mark))
                rows.Add(new[] { key, childLogin, mark });
            WriteRows(MarksFile, rows);
        }

        public static bool IsPaid(string login, int year, int month)
        {
            return ReadRows(PaymentsFile).Any(r =>
                r.Length >= 3 &&
                string.Equals(r[0], login, StringComparison.OrdinalIgnoreCase) &&
                r[1] == year.ToString() && r[2] == month.ToString());
        }

        public static void AddPayment(string login, int year, int month, int amount)
        {
            List<string[]> rows = ReadRows(PaymentsFile);
            rows.Add(new[]
            {
                login, year.ToString(), month.ToString(), amount.ToString(),
                DateTime.Now.ToString("dd.MM.yyyy HH:mm")
            });
            WriteRows(PaymentsFile, rows);
        }

        public static List<string> GetPayments(string login)
        {
            var result = new List<string>();
            foreach (string[] r in ReadRows(PaymentsFile))
            {
                if (r.Length < 5) continue;
                if (!string.Equals(r[0], login, StringComparison.OrdinalIgnoreCase)) continue;
                int month;
                if (!int.TryParse(r[2], out month) || month < 1 || month > 12) continue;
                result.Add(r[4] + "  " + MonthNames[month - 1] + " " + r[1] + ": " + r[3] + " руб.");
            }
            result.Reverse();
            return result;
        }

        public static void AddNotification(string author, string text)
        {
            Directory.CreateDirectory(Folder);
            string line = string.Join(";", new[]
            {
                B64(DateTime.Now.ToString("dd.MM.yyyy HH:mm")), B64(author), B64(text)
            });
            File.AppendAllLines(NotificationsFile, new[] { line }, Encoding.UTF8);
        }

        public static List<string> GetNotifications()
        {
            var result = new List<string>();
            if (!File.Exists(NotificationsFile)) return result;
            foreach (string line in File.ReadAllLines(NotificationsFile, Encoding.UTF8))
            {
                try
                {
                    string[] p = line.Split(';');
                    if (p.Length != 3) continue;
                    result.Add(FromB64(p[0]) + "  " + FromB64(p[1]) + ":\n" + FromB64(p[2]));
                }
                catch (FormatException)
                {
                }
            }
            return result;
        }

        private static byte[] Derive(string password, byte[] salt)
        {
            using (var kdf = new Rfc2898DeriveBytes(password, salt, 10000))
            {
                return kdf.GetBytes(32);
            }
        }

        private static string Hash(string password)
        {
            byte[] salt = new byte[16];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }
            return Convert.ToBase64String(salt) + ":" + Convert.ToBase64String(Derive(password, salt));
        }

        private static bool Verify(string password, string stored)
        {
            if (string.IsNullOrEmpty(stored)) return false;
            string[] parts = stored.Split(':');
            if (parts.Length != 2) return false;

            byte[] salt;
            byte[] expected;
            try
            {
                salt = Convert.FromBase64String(parts[0]);
                expected = Convert.FromBase64String(parts[1]);
            }
            catch (FormatException)
            {
                return false;
            }

            byte[] actual = Derive(password, salt);
            if (actual.Length != expected.Length) return false;
            int diff = 0;
            for (int i = 0; i < actual.Length; i++)
                diff |= actual[i] ^ expected[i];
            return diff == 0;
        }
    }
}