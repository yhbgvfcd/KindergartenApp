﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace KindergartenApp
{
    public partial class LoginForm : Form
    {
        private readonly string _role;

        public LoginForm(string role)
        {
            InitializeComponent();
            _role = role;

            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            UiHelper.MakeSingleLine(txtLogin);
            UiHelper.MakePassword(txtPassword);

            lblSubHeader.Text = _role == Roles.Teacher ? "ВХОД ДЛЯ ВОСПИТАТЕЛЯ" : "ВХОД ДЛЯ РОДИТЕЛЯ";

            AcceptButton = btnLogin;

            btnLogin.Click += btnLogin_Click;
            linkRegister.LinkClicked += linkRegister_LinkClicked;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;

            if (login.Length == 0 || password.Length == 0)
            {
                UiHelper.Warn("Введите логин и пароль.");
                return;
            }

            User user = DataStore.Authenticate(login, password, _role);
            if (user == null)
            {
                UiHelper.Warn("Неверный логин или пароль.");
                txtPassword.Clear();
                txtPassword.Focus();
                return;
            }

            Session.Current = user;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void linkRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (_role == Roles.Teacher)
            {
                using (var reg = new RegisterTeacherForm())
                {
                    if (reg.ShowDialog(this) == DialogResult.OK)
                    {
                        txtLogin.Text = reg.RegisteredLogin;
                        txtPassword.Clear();
                        txtPassword.Focus();
                    }
                }
            }
            else
            {
                using (var reg = new RegisterParentForm())
                {
                    if (reg.ShowDialog(this) == DialogResult.OK)
                    {
                        txtLogin.Text = reg.RegisteredLogin;
                        txtPassword.Clear();
                        txtPassword.Focus();
                    }
                }
            }
        }
    }
}
