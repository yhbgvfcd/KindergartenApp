﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace KindergartenApp
{
    public partial class ProfileFormTeacher : Form
    {
        public ProfileFormTeacher()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;

            if (Session.Current != null)
            {
                lblName.Text = Session.Current.DisplayName.ToUpper();
                
            }
            btnLogin.Click += (s, e) => UiHelper.Info("Логин: " + Session.Current.Login);
            btnEmail.Click += (s, e) => UiHelper.Info("Почта: " + Session.Current.Email);
            btnChangePassword.Click += (s, e) => ChangePasswordForm.Run(Session.Current);
            btnNotifyParents.Click += btnNotifyParents_Click;
            btnLogout.Click += (s, e) =>
            {
                Session.Current = null;
                DialogResult = DialogResult.Abort;
                Close();
            };
        }
        private void btnNotifyParents_Click(object sender, EventArgs e)
        {
            using (var form = new NotifyForm())
            {
                if (form.ShowDialog(this) != DialogResult.OK) return;

                DataStore.AddNotification(Session.Current.DisplayName, form.MessageText);
                UiHelper.Info("Уведомление отправлено!");
            }
        }
    }
}
