﻿using KindergartenApp;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace KindergartenApp
{
    public partial class MainForm : Form
    {
        private readonly bool _isTeacher;
        private readonly string[] _daysOfWeek = {
            "ПОНЕДЕЛЬНИК", "ВТОРНИК", "СРЕДА", "ЧЕТВЕРГ", "ПЯТНИЦА", "СУББОТА", "ВОСКРЕСЕНЬЕ"
        };

        public MainForm()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            _isTeacher = Session.Current != null && Session.Current.Role == Roles.Teacher;

            if (Session.Current != null)
            {
                lblName.Text = Session.Current.DisplayName.ToUpper();
            }

            if (_isTeacher && tabMain.TabPages.Contains(tabPayment))
            {
                tabMain.TabPages.Remove(tabPayment);
            }
            if (!_isTeacher && tabMain.TabPages.Contains(tabChildren))
            {
                tabMain.TabPages.Remove(tabChildren);
            }
            if (_isTeacher)
            {
                LoadChildren();
            }
            SetupTables();
            LoadSchedule();
            LoadAttendance();

            if (!_isTeacher)
            {
                LoadPaymentData();
            }

            btnPay.Click += btnPay_Click;
            tabMain.Selecting += tabMain_Selecting;
            dgvSchedule.CellEndEdit += dgvSchedule_CellEndEdit;
            dgvSchedule.SelectionChanged += dgvSchedule_SelectionChanged;
            dgvAttendance.CellDoubleClick += dgvAttendance_CellDoubleClick;
        }

        private void SetupTables()
        {
            Font cellFont = UiHelper.AppFont(9, FontStyle.Regular);

            dgvSchedule.DefaultCellStyle.Font = cellFont;
            dgvSchedule.RowHeadersVisible = false;
            dgvSchedule.AllowUserToAddRows = false;
            dgvSchedule.AllowUserToDeleteRows = false;
            dgvSchedule.ReadOnly = !_isTeacher;
            dgvSchedule.Columns[0].ReadOnly = true;
            dgvSchedule.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSchedule.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvSchedule.RowTemplate.Height = 25;
            dgvSchedule.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dgvSchedule.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;

            dgvAttendance.DefaultCellStyle.Font = cellFont;
            dgvAttendance.RowHeadersVisible = false;
            dgvAttendance.AllowUserToAddRows = false;
            dgvAttendance.AllowUserToDeleteRows = false;
            dgvAttendance.ReadOnly = true;
            dgvAttendance.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAttendance.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAttendance.RowTemplate.Height = 25;
        }

        private void LoadSchedule()
        {
            dgvSchedule.Rows.Clear();
            List<string[]> schedule = DataStore.LoadSchedule();

            if (schedule == null) schedule = new List<string[]>();

            for (int i = 0; i < _daysOfWeek.Length; i++)
            {
                string time = "";
                if (i < schedule.Count && schedule[i] != null && schedule[i].Length >= 1)
                {
                    time = schedule[i][0] ?? "";
                }
                dgvSchedule.Rows.Add(_daysOfWeek[i], time);
            }

            if (dgvSchedule.Rows.Count > 0)
            {
                dgvSchedule.Rows[0].Selected = true;
                UpdateSelectedDayInfo(0);
            }
        }

        private void dgvSchedule_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSchedule.SelectedRows.Count > 0)
            {
                int index = dgvSchedule.SelectedRows[0].Index;
                if (index >= 0 && index < dgvSchedule.Rows.Count)
                {
                    UpdateSelectedDayInfo(index);
                }
            }
        }

        private void UpdateSelectedDayInfo(int rowIndex)
        {
            if (rowIndex < 0 || rowIndex >= dgvSchedule.Rows.Count) return;

            string day = dgvSchedule.Rows[rowIndex].Cells[0].Value?.ToString() ?? "";
            string time = dgvSchedule.Rows[rowIndex].Cells[1].Value?.ToString() ?? "";

            lblSelectedDayInfo.Text = $"{day}:\n{time}";
        }

        private void dgvSchedule_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!_isTeacher || e.RowIndex < 0) return;
            SaveScheduleToFile();
            UpdateSelectedDayInfo(e.RowIndex);
        }

        private void SaveScheduleToFile()
        {
            List<string[]> schedule = new List<string[]>();
            for (int i = 0; i < dgvSchedule.Rows.Count; i++)
            {
                schedule.Add(new[] {
                    dgvSchedule.Rows[i].Cells[1].Value?.ToString() ?? ""
                });
            }
            DataStore.SaveSchedule(schedule);
        }

        private static DateTime StartOfWeek()
        {
            int diff = ((int)DateTime.Today.DayOfWeek + 6) % 7;
            return DateTime.Today.AddDays(-diff);
        }

        private void AddAttendanceRows(string login, string childName, DateTime start)
        {
            Dictionary<string, string> marks = DataStore.GetMarks(login);
            for (int i = 0; i < 7; i++)
            {
                DateTime date = start.AddDays(i);
                string status;
                marks.TryGetValue(DataStore.DateKey(date), out status);
                int idx = dgvAttendance.Rows.Add(childName, date.ToString("dd.MM.yyyy"), status ?? "");
                dgvAttendance.Rows[idx].Tag = login;
            }
        }

        private void LoadAttendance()
        {
            dgvAttendance.Rows.Clear();
            if (Session.Current == null) return;

            DateTime start = StartOfWeek();

            if (!_isTeacher)
            {
                AddAttendanceRows(Session.Current.Login, Session.Current.ChildFullName, start);
                return;
            }

            foreach (var parent in DataStore.GetParents())
            {
                if (string.IsNullOrEmpty(parent.ChildFullName)) continue;
                AddAttendanceRows(parent.Login, parent.ChildFullName, start);
            }
        }

        private void dgvAttendance_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (!_isTeacher || e.RowIndex < 0 || e.ColumnIndex != 2) return;

            string newStatus = StatusForm.Ask();
            if (newStatus == null) return;

            DataGridViewRow row = dgvAttendance.Rows[e.RowIndex];
            string login = row.Tag as string;
            DateTime date;
            if (login == null ||
                !DateTime.TryParseExact(row.Cells[1].Value?.ToString(), "dd.MM.yyyy",
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None, out date))
                return;

            DataStore.SetMark(date, login, newStatus);
            row.Cells[2].Value = newStatus;
        }

        private void LoadPaymentData()
        {
            dtpMonth.Format = DateTimePickerFormat.Custom;
            dtpMonth.CustomFormat = "MMMM";
            dtpMonth.ShowUpDown = true;
            dtpMonth.Value = DateTime.Today;

            dtpMonth.ValueChanged += DtpMonth_ValueChanged;
            DtpMonth_ValueChanged(null, null);
        }

        private void DtpMonth_ValueChanged(object sender, EventArgs e)
        {
            if (Session.Current == null) return;

            int month = dtpMonth.Value.Month;
            int year = dtpMonth.Value.Year;
            bool isPaid = DataStore.IsPaid(Session.Current.Login, year, month);

            if (isPaid)
            {
                lblTotalSum.Text = "ОПЛАЧЕНО";
                lblTotalSum.ForeColor = Color.Green;
                btnPay.Enabled = false;
            }
            else
            {
                lblTotalSum.Text = "5 000 руб.";
                lblTotalSum.ForeColor = Color.Black;
                btnPay.Enabled = true;
            }
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if (Session.Current == null) return;

            int month = dtpMonth.Value.Month;
            int year = dtpMonth.Value.Year;

            DataStore.AddPayment(Session.Current.Login, year, month, 5000);

            MessageBox.Show($"Оплата за {dtpMonth.Text} прошла успешно!\nСумма: 5 000 руб.", "Успех",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            DtpMonth_ValueChanged(null, null);
        }

        private void tabMain_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (e.TabPage == tabAttendance && _isTeacher)
            {
                LoadAttendance();
            }
        }

        private void btnProfile_Click_1(object sender, EventArgs e)
        {
            bool isTeacher = Session.Current != null && Session.Current.Role == Roles.Teacher;
            using (Form profile = isTeacher ? (Form)new ProfileFormTeacher() : new ProfileFormParent())
            {
                DialogResult result = profile.ShowDialog(this);
                if (result == DialogResult.Abort || Session.Current == null)
                {
                    this.Close();
                }
            }
        }
        private void LoadChildren()
        {
            dgvChildren.Rows.Clear();

            var parents = DataStore.GetParents();

            foreach (var parent in parents)
            {
                if (string.IsNullOrWhiteSpace(parent.ChildFullName)) continue;

                string birthDate = parent.BirthDate;
                DateTime dt;
                if (DateTime.TryParse(birthDate, out dt))
                {
                    birthDate = dt.ToString("dd.MM.yyyy"); 
                }
                else if (string.IsNullOrWhiteSpace(birthDate))
                {
                    birthDate = "—";
                }
                string medical = string.IsNullOrWhiteSpace(parent.MedicalNotes)
                    ? "—"
                    : parent.MedicalNotes;

                int rowIndex = dgvChildren.Rows.Add();
                dgvChildren.Rows[rowIndex].Cells["ChildName"].Value = parent.ChildFullName;
                dgvChildren.Rows[rowIndex].Cells["BirthDate"].Value = birthDate;
                dgvChildren.Rows[rowIndex].Cells["Medical"].Value = medical;
            }
        }
    }
}