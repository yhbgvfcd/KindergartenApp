﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace KindergartenApp
{
    public partial class ProfileFormParent : Form
    {
        public ProfileFormParent()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FillProfile();
        }

        private void FillProfile()
        {
            User user = Session.Current;
            if (user == null) return;

            lblName.Text = user.DisplayName.ToUpper();
            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (Session.Current == null) return;
            UiHelper.Info("Ваш логин: " + Session.Current.Login);
        }

        private void btnEmail_Click(object sender, EventArgs e)
        {
            if (Session.Current == null) return;
            UiHelper.Info("Электронная почта: " + Session.Current.Email);
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            ChangePasswordForm.Run(Session.Current);
        }

        private void btnNotifications_Click(object sender, EventArgs e)
        {
            using (var form = new NotificationsForm())
            {
                form.ShowDialog(this);
            }
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            if (Session.Current == null) return;
            using (var form = new PaymentHistoryForm())
            {
                form.ShowDialog(this);
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Current = null;
            DialogResult = DialogResult.Abort;
            Close();
        }
    }
}
