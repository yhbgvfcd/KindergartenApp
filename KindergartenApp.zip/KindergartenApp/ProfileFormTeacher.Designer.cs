﻿namespace KindergartenApp
{
    partial class ProfileFormTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProfileFormTeacher));
            this.btnNotifyParents = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnChangePassword = new System.Windows.Forms.Button();
            this.btnEmail = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.picAvatar = new System.Windows.Forms.PictureBox();
            this.lblName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNotifyParents
            // 
            this.btnNotifyParents.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.btnNotifyParents.FlatAppearance.BorderSize = 0;
            this.btnNotifyParents.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnNotifyParents.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnNotifyParents.Location = new System.Drawing.Point(12, 204);
            this.btnNotifyParents.Name = "btnNotifyParents";
            this.btnNotifyParents.Size = new System.Drawing.Size(276, 36);
            this.btnNotifyParents.TabIndex = 59;
            this.btnNotifyParents.Text = "УВЕДОМИТЬ РОДИТЕЛЕЙ";
            this.btnNotifyParents.UseVisualStyleBackColor = false;
            this.btnNotifyParents.Click += new System.EventHandler(this.btnNotifyParents_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(202)))), ((int)(((byte)(231)))));
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnLogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLogout.Location = new System.Drawing.Point(12, 374);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(276, 36);
            this.btnLogout.TabIndex = 58;
            this.btnLogout.Text = "ВЫЙТИ";
            this.btnLogout.UseVisualStyleBackColor = false;
            // 
            // btnChangePassword
            // 
            this.btnChangePassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.btnChangePassword.FlatAppearance.BorderSize = 0;
            this.btnChangePassword.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnChangePassword.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnChangePassword.Location = new System.Drawing.Point(12, 162);
            this.btnChangePassword.Name = "btnChangePassword";
            this.btnChangePassword.Size = new System.Drawing.Size(276, 36);
            this.btnChangePassword.TabIndex = 57;
            this.btnChangePassword.Text = "ПОМЕНЯТЬ ПАРОЛЬ";
            this.btnChangePassword.UseVisualStyleBackColor = false;
            // 
            // btnEmail
            // 
            this.btnEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.btnEmail.FlatAppearance.BorderSize = 0;
            this.btnEmail.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnEmail.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEmail.Location = new System.Drawing.Point(12, 120);
            this.btnEmail.Name = "btnEmail";
            this.btnEmail.Size = new System.Drawing.Size(276, 36);
            this.btnEmail.TabIndex = 56;
            this.btnEmail.Text = "ЭЛЕКТРОННАЯ ПОЧТА";
            this.btnEmail.UseVisualStyleBackColor = false;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnLogin.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLogin.Location = new System.Drawing.Point(12, 78);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(276, 36);
            this.btnLogin.TabIndex = 55;
            this.btnLogin.Text = "ЛОГИН";
            this.btnLogin.UseVisualStyleBackColor = false;
            // 
            // picAvatar
            // 
            this.picAvatar.Image = ((System.Drawing.Image)(resources.GetObject("picAvatar.Image")));
            this.picAvatar.Location = new System.Drawing.Point(12, 15);
            this.picAvatar.Name = "picAvatar";
            this.picAvatar.Size = new System.Drawing.Size(36, 32);
            this.picAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAvatar.TabIndex = 54;
            this.picAvatar.TabStop = false;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.lblName.Location = new System.Drawing.Point(54, 23);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(114, 16);
            this.lblName.TabIndex = 53;
            this.lblName.Text = "ФАМИЛИЯ ИМЯ";
            // 
            // ProfileFormTeacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(308, 429);
            this.Controls.Add(this.btnNotifyParents);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnChangePassword);
            this.Controls.Add(this.btnEmail);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.picAvatar);
            this.Controls.Add(this.lblName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProfileFormTeacher";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNotifyParents;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnChangePassword;
        private System.Windows.Forms.Button btnEmail;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.PictureBox picAvatar;
        private System.Windows.Forms.Label lblName;
    }
}