﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KindergartenApp
{
    public partial class NotifyForm : Form
    {
        public string MessageText { get; private set; }

        public NotifyForm()
        {
            InitializeComponent();

            btnOk.DialogResult = DialogResult.None;
            btnOk.Click -= btnOk_Click;
            btnOk.Click += btnOk_Click;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string text = txtText.Text.Trim();
            if (text.Length == 0)
            {
                UiHelper.Warn("Введите текст уведомления.");
                txtText.Focus();
                return;
            }

            MessageText = text;
            DialogResult = DialogResult.OK;
        }
    }
}
