﻿namespace KindergartenApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabSchedule = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblSelectedDayTitle = new System.Windows.Forms.Label();
            this.lblSelectedDayInfo = new System.Windows.Forms.Label();
            this.dgvSchedule = new System.Windows.Forms.DataGridView();
            this.colDay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblWeekSchedule = new System.Windows.Forms.Label();
            this.tabAttendance = new System.Windows.Forms.TabPage();
            this.dgvAttendance = new System.Windows.Forms.DataGridView();
            this.colChildName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSun = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPayment = new System.Windows.Forms.TabPage();
            this.dtpMonth = new System.Windows.Forms.DateTimePicker();
            this.btnPay = new System.Windows.Forms.Button();
            this.lblTotalSum = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabChildren = new System.Windows.Forms.TabPage();
            this.dgvChildren = new System.Windows.Forms.DataGridView();
            this.ChildName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BirthDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Medical = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.picAvatar = new System.Windows.Forms.PictureBox();
            this.lblName = new System.Windows.Forms.Label();
            this.btnProfile = new System.Windows.Forms.Button();
            this.tabMain.SuspendLayout();
            this.tabSchedule.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSchedule)).BeginInit();
            this.tabAttendance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAttendance)).BeginInit();
            this.tabPayment.SuspendLayout();
            this.tabChildren.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChildren)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabSchedule);
            this.tabMain.Controls.Add(this.tabAttendance);
            this.tabMain.Controls.Add(this.tabPayment);
            this.tabMain.Controls.Add(this.tabChildren);
            this.tabMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabMain.Location = new System.Drawing.Point(16, 64);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(613, 464);
            this.tabMain.TabIndex = 40;
            // 
            // tabSchedule
            // 
            this.tabSchedule.BackColor = System.Drawing.Color.White;
            this.tabSchedule.Controls.Add(this.groupBox1);
            this.tabSchedule.Controls.Add(this.dgvSchedule);
            this.tabSchedule.Controls.Add(this.lblWeekSchedule);
            this.tabSchedule.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSchedule.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.tabSchedule.Location = new System.Drawing.Point(4, 24);
            this.tabSchedule.Name = "tabSchedule";
            this.tabSchedule.Padding = new System.Windows.Forms.Padding(3);
            this.tabSchedule.Size = new System.Drawing.Size(605, 436);
            this.tabSchedule.TabIndex = 0;
            this.tabSchedule.Text = "РАСПИСАНИЕ";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.groupBox1.Controls.Add(this.lblSelectedDayTitle);
            this.groupBox1.Controls.Add(this.lblSelectedDayInfo);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(-9, -11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(618, 170);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            // 
            // lblSelectedDayTitle
            // 
            this.lblSelectedDayTitle.AutoSize = true;
            this.lblSelectedDayTitle.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedDayTitle.ForeColor = System.Drawing.Color.White;
            this.lblSelectedDayTitle.Location = new System.Drawing.Point(20, 30);
            this.lblSelectedDayTitle.Name = "lblSelectedDayTitle";
            this.lblSelectedDayTitle.Size = new System.Drawing.Size(181, 21);
            this.lblSelectedDayTitle.TabIndex = 0;
            this.lblSelectedDayTitle.Text = "ВЫБРАННЫЙ ДЕНЬ:";
            // 
            // lblSelectedDayInfo
            // 
            this.lblSelectedDayInfo.AutoSize = true;
            this.lblSelectedDayInfo.Font = new System.Drawing.Font("Coolvetica", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedDayInfo.ForeColor = System.Drawing.Color.White;
            this.lblSelectedDayInfo.Location = new System.Drawing.Point(21, 61);
            this.lblSelectedDayInfo.Name = "lblSelectedDayInfo";
            this.lblSelectedDayInfo.Size = new System.Drawing.Size(107, 15);
            this.lblSelectedDayInfo.TabIndex = 1;
            this.lblSelectedDayInfo.Text = "ВРЕМЯ - ЗАНИТИЕ";
            // 
            // dgvSchedule
            // 
            this.dgvSchedule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSchedule.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvSchedule.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSchedule.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDay,
            this.colTime});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSchedule.DefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSchedule.Location = new System.Drawing.Point(15, 214);
            this.dgvSchedule.Name = "dgvSchedule";
            this.dgvSchedule.RowHeadersVisible = false;
            this.dgvSchedule.Size = new System.Drawing.Size(574, 202);
            this.dgvSchedule.TabIndex = 3;
            // 
            // colDay
            // 
            this.colDay.HeaderText = "День недели";
            this.colDay.Name = "colDay";
            // 
            // colTime
            // 
            this.colTime.HeaderText = "Занятие";
            this.colTime.Name = "colTime";
            // 
            // lblWeekSchedule
            // 
            this.lblWeekSchedule.AutoSize = true;
            this.lblWeekSchedule.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWeekSchedule.Location = new System.Drawing.Point(11, 180);
            this.lblWeekSchedule.Name = "lblWeekSchedule";
            this.lblWeekSchedule.Size = new System.Drawing.Size(248, 21);
            this.lblWeekSchedule.TabIndex = 2;
            this.lblWeekSchedule.Text = "РАСПИСАНИЕ НА НЕДЕЛЮ:";
            // 
            // tabAttendance
            // 
            this.tabAttendance.BackColor = System.Drawing.Color.White;
            this.tabAttendance.Controls.Add(this.dgvAttendance);
            this.tabAttendance.Controls.Add(this.label2);
            this.tabAttendance.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabAttendance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.tabAttendance.Location = new System.Drawing.Point(4, 24);
            this.tabAttendance.Name = "tabAttendance";
            this.tabAttendance.Padding = new System.Windows.Forms.Padding(3);
            this.tabAttendance.Size = new System.Drawing.Size(605, 436);
            this.tabAttendance.TabIndex = 1;
            this.tabAttendance.Text = "ПОСЕЩАЕМОСТЬ";
            // 
            // dgvAttendance
            // 
            this.dgvAttendance.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAttendance.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvAttendance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAttendance.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colChildName,
            this.colSun,
            this.colStatus});
            this.dgvAttendance.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dgvAttendance.Location = new System.Drawing.Point(21, 54);
            this.dgvAttendance.Name = "dgvAttendance";
            this.dgvAttendance.RowHeadersVisible = false;
            this.dgvAttendance.Size = new System.Drawing.Size(557, 364);
            this.dgvAttendance.TabIndex = 4;
            // 
            // colChildName
            // 
            this.colChildName.HeaderText = "Имя";
            this.colChildName.Name = "colChildName";
            // 
            // colSun
            // 
            this.colSun.HeaderText = "Дата";
            this.colSun.Name = "colSun";
            // 
            // colStatus
            // 
            this.colStatus.HeaderText = "Статус";
            this.colStatus.Name = "colStatus";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(325, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "ПОСЕЩАЕМОСТЬ НА ЭТОЙ НЕДЕЛЕ:";
            // 
            // tabPayment
            // 
            this.tabPayment.BackColor = System.Drawing.Color.White;
            this.tabPayment.Controls.Add(this.dtpMonth);
            this.tabPayment.Controls.Add(this.btnPay);
            this.tabPayment.Controls.Add(this.lblTotalSum);
            this.tabPayment.Controls.Add(this.label4);
            this.tabPayment.Controls.Add(this.label3);
            this.tabPayment.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPayment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.tabPayment.Location = new System.Drawing.Point(4, 24);
            this.tabPayment.Name = "tabPayment";
            this.tabPayment.Padding = new System.Windows.Forms.Padding(3);
            this.tabPayment.Size = new System.Drawing.Size(605, 436);
            this.tabPayment.TabIndex = 2;
            this.tabPayment.Text = "ОПЛАТА";
            // 
            // dtpMonth
            // 
            this.dtpMonth.CustomFormat = "MMMM";
            this.dtpMonth.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpMonth.Location = new System.Drawing.Point(21, 52);
            this.dtpMonth.Name = "dtpMonth";
            this.dtpMonth.ShowUpDown = true;
            this.dtpMonth.Size = new System.Drawing.Size(558, 27);
            this.dtpMonth.TabIndex = 38;
            // 
            // btnPay
            // 
            this.btnPay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(211)))), ((int)(((byte)(114)))));
            this.btnPay.FlatAppearance.BorderSize = 0;
            this.btnPay.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnPay.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPay.Location = new System.Drawing.Point(21, 132);
            this.btnPay.Name = "btnPay";
            this.btnPay.Size = new System.Drawing.Size(558, 38);
            this.btnPay.TabIndex = 37;
            this.btnPay.Text = "ОПЛАТИТЬ";
            this.btnPay.UseVisualStyleBackColor = false;
            // 
            // lblTotalSum
            // 
            this.lblTotalSum.AutoSize = true;
            this.lblTotalSum.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalSum.Location = new System.Drawing.Point(87, 91);
            this.lblTotalSum.Name = "lblTotalSum";
            this.lblTotalSum.Size = new System.Drawing.Size(16, 21);
            this.lblTotalSum.TabIndex = 7;
            this.lblTotalSum.Text = "-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 21);
            this.label4.TabIndex = 6;
            this.label4.Text = "ИТОГО: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Coolvetica", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "МЕСЯЦ:";
            // 
            // tabChildren
            // 
            this.tabChildren.Controls.Add(this.dgvChildren);
            this.tabChildren.Location = new System.Drawing.Point(4, 24);
            this.tabChildren.Name = "tabChildren";
            this.tabChildren.Padding = new System.Windows.Forms.Padding(3);
            this.tabChildren.Size = new System.Drawing.Size(605, 436);
            this.tabChildren.TabIndex = 3;
            this.tabChildren.Text = "ДЕТИ";
            this.tabChildren.UseVisualStyleBackColor = true;
            // 
            // dgvChildren
            // 
            this.dgvChildren.AllowUserToAddRows = false;
            this.dgvChildren.AllowUserToDeleteRows = false;
            this.dgvChildren.AllowUserToResizeRows = false;
            this.dgvChildren.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChildren.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvChildren.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChildren.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ChildName,
            this.BirthDate,
            this.Medical});
            this.dgvChildren.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dgvChildren.Location = new System.Drawing.Point(24, 18);
            this.dgvChildren.Name = "dgvChildren";
            this.dgvChildren.ReadOnly = true;
            this.dgvChildren.RowHeadersVisible = false;
            this.dgvChildren.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChildren.Size = new System.Drawing.Size(557, 399);
            this.dgvChildren.TabIndex = 5;
            // 
            // ChildName
            // 
            this.ChildName.HeaderText = "Имя Фамилия";
            this.ChildName.Name = "ChildName";
            this.ChildName.ReadOnly = true;
            // 
            // BirthDate
            // 
            this.BirthDate.HeaderText = "Дата рождения";
            this.BirthDate.Name = "BirthDate";
            this.BirthDate.ReadOnly = true;
            // 
            // Medical
            // 
            this.Medical.HeaderText = "Медицинские данные";
            this.Medical.Name = "Medical";
            this.Medical.ReadOnly = true;
            // 
            // picAvatar
            // 
            this.picAvatar.Image = ((System.Drawing.Image)(resources.GetObject("picAvatar.Image")));
            this.picAvatar.Location = new System.Drawing.Point(16, 13);
            this.picAvatar.Name = "picAvatar";
            this.picAvatar.Size = new System.Drawing.Size(36, 32);
            this.picAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAvatar.TabIndex = 39;
            this.picAvatar.TabStop = false;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(159)))), ((int)(((byte)(216)))));
            this.lblName.Location = new System.Drawing.Point(58, 21);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(114, 16);
            this.lblName.TabIndex = 38;
            this.lblName.Text = "ФАМИЛИЯ ИМЯ";
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(211)))), ((int)(((byte)(114)))));
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.Font = new System.Drawing.Font("Coolvetica", 8.999999F, System.Drawing.FontStyle.Bold);
            this.btnProfile.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnProfile.Location = new System.Drawing.Point(524, 13);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(101, 32);
            this.btnProfile.TabIndex = 37;
            this.btnProfile.Text = "ПРОФИЛЬ";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click_1);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(650, 550);
            this.Controls.Add(this.tabMain);
            this.Controls.Add(this.picAvatar);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnProfile);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.tabMain.ResumeLayout(false);
            this.tabSchedule.ResumeLayout(false);
            this.tabSchedule.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSchedule)).EndInit();
            this.tabAttendance.ResumeLayout(false);
            this.tabAttendance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAttendance)).EndInit();
            this.tabPayment.ResumeLayout(false);
            this.tabPayment.PerformLayout();
            this.tabChildren.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChildren)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabSchedule;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblSelectedDayTitle;
        private System.Windows.Forms.Label lblSelectedDayInfo;
        private System.Windows.Forms.DataGridView dgvSchedule;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDay;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTime;
        private System.Windows.Forms.Label lblWeekSchedule;
        private System.Windows.Forms.TabPage tabAttendance;
        private System.Windows.Forms.DataGridView dgvAttendance;
        private System.Windows.Forms.DataGridViewTextBoxColumn colChildName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSun;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPayment;
        private System.Windows.Forms.DateTimePicker dtpMonth;
        private System.Windows.Forms.Button btnPay;
        private System.Windows.Forms.Label lblTotalSum;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox picAvatar;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.TabPage tabChildren;
        private System.Windows.Forms.DataGridView dgvChildren;
        private System.Windows.Forms.DataGridViewTextBoxColumn ChildName;
        private System.Windows.Forms.DataGridViewTextBoxColumn BirthDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Medical;
    }
}