﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KindergartenApp
{
    public partial class StatusForm : Form
    {
        public string SelectedStatus { get; private set; }
        public StatusForm()
        {
            InitializeComponent();
            
            btnWas.Click += (s, e) => Choose("БЫЛ(А)");
            btnSick.Click += (s, e) => Choose("БОЛЕЕТ");
            btnAbsent.Click += (s, e) => Choose("ОТСУТСТВОВАЛ(А)");
        }
        private void Choose(string status)
        {
            SelectedStatus = status;
            DialogResult = DialogResult.OK;
        }

        public static string Ask()
        {
            using (var form = new StatusForm())
            {
                return form.ShowDialog() == DialogResult.OK ? form.SelectedStatus : null;
            }
        }
    }
}
