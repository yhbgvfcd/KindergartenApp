﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace KindergartenApp
{
    public partial class RegisterParentForm : Form
    {
        public string RegisteredLogin { get; private set; }
        public RegisterParentForm()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            UiHelper.SingleLineAll(this);
            UiHelper.MakePassword(txtPassword);
            txtMedicalNotes.Multiline = true;
            txtMedicalNotes.ScrollBars = ScrollBars.Vertical;

            dtpBirthDate.Format = DateTimePickerFormat.Short;
            dtpBirthDate.MaxDate = DateTime.Today;
            dtpBirthDate.Value = DateTime.Today;

            AcceptButton = btnContinue;

            btnContinue.Click -= btnContinue_Click;
            btnContinue.Click += btnContinue_Click;
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string childName = txtChildName.Text.Trim();
            string childSurname = txtChildSurname.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text;
            string medicalNotes = txtMedicalNotes.Text.Trim();


            if (login.Length < 3)
            {
                UiHelper.Warn("Логин должен содержать не менее 3 символов.");
                txtLogin.Focus();
                return;
            }
            if (childName.Length == 0)
            {
                UiHelper.Warn("Введите имя ребёнка.");
                txtChildName.Focus();
                return;
            }
            if (childSurname.Length == 0)
            {
                UiHelper.Warn("Введите фамилию ребёнка.");
                txtChildSurname.Focus();
                return;
            }
            if (dtpBirthDate.Value.Date >= DateTime.Today)
            {
                UiHelper.Warn("Укажите корректную дату рождения ребёнка.");
                dtpBirthDate.Focus();
                return;
            }
            if (!UiHelper.IsValidEmail(email))
            {
                UiHelper.Warn("Введите корректный адрес электронной почты.");
                txtEmail.Focus();
                return;
            }
            if (password.Length < 6)
            {
                UiHelper.Warn("Пароль должен содержать не менее 6 символов.");
                txtPassword.Focus();
                return;
            }
            if (medicalNotes.Length > 500)
            {
                UiHelper.Warn("Медицинские отметки не должны превышать 500 символов.");
                txtMedicalNotes.Focus();
                return;
            }

            var user = new User
            {
                Role = Roles.Parent,
                Login = login,
                Email = email,
                ChildName = childName,
                ChildSurname = childSurname,
                BirthDate = dtpBirthDate.Value.Date.ToString("yyyy-MM-dd"),
                Name = "",
                Surname = "",
                MedicalNotes = medicalNotes
            };

            string error;
            if (!DataStore.Register(user, password, out error))
            {
                UiHelper.Warn(error);
                return;
            }

            RegisteredLogin = login;
            UiHelper.Info("Регистрация прошла успешно. Теперь войдите в аккаунт.");
            DialogResult = DialogResult.OK;
        }
    }
}
