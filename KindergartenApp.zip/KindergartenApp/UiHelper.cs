﻿using System;
using System.Drawing;
using System.Drawing.Text;
using System.Net.Mail;
using System.Windows.Forms;

namespace KindergartenApp
{
    internal static class UiHelper
    {      
        public static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new MailAddress(email);
                return addr.Address == email && email.Contains(".");
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static void Info(string text)
        {
            MessageBox.Show(text, "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static void Warn(string text)
        {
            MessageBox.Show(text, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void Error(string text)
        {
            MessageBox.Show(text, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}