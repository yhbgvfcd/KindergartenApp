﻿using System;
using System.Drawing;
using System.Drawing.Text;
using System.Net.Mail;
using System.Windows.Forms;

namespace KindergartenApp
{
    internal static class UiHelper
    {
        private static string _fontName;

        public static Font AppFont(float size, FontStyle style)
        {
            if (_fontName == null)
            {
                _fontName = "Segoe UI";
                using (var fc = new InstalledFontCollection())
                {
                    foreach (FontFamily f in fc.Families)
                    {
                        if (f.Name == "Coolvetica")
                        {
                            _fontName = "Coolvetica";
                            break;
                        }
                    }
                }
            }
            return new Font(_fontName, size, style);
        }

        public static void MakeSingleLine(TextBox tb)
        {
            Size size = tb.Size;
            tb.Multiline = false;
            tb.AutoSize = false;
            tb.Size = size;
        }

        public static void MakePassword(TextBox tb)
        {
            MakeSingleLine(tb);
            tb.UseSystemPasswordChar = true;
        }

        public static void SingleLineAll(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                var tb = c as TextBox;
                if (tb != null) MakeSingleLine(tb);
            }
        }

        public static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new MailAddress(email);
                return addr.Address == email && email.Contains(".");
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static void Info(string text)
        {
            MessageBox.Show(text, "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static void Warn(string text)
        {
            MessageBox.Show(text, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        public static void Error(string text)
        {
            MessageBox.Show(text, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}