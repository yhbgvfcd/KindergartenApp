﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KindergartenApp
{
    public partial class ChangePasswordForm : Form
    {
        private User _user;
        public ChangePasswordForm()
        {
            InitializeComponent();
            AcceptButton = btnSave;
            btnSave.Click += btnSave_Click;
        }
        public static void Run(User user)
        {
            if (user == null)
            {
                UiHelper.Warn("Пользователь не определён.");
                return;
            }

            using (var form = new ChangePasswordForm())
            {
                form._user = user;
                form.ShowDialog();
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_user == null) return;

            if (txtOldPassword.Text.Length == 0)
            {
                UiHelper.Warn("Введите текущий пароль.");
                txtOldPassword.Focus();
                return;
            }
            if (txtNewPassword.Text.Length < 6)
            {
                UiHelper.Warn("Новый пароль должен содержать не менее 6 символов.");
                txtNewPassword.Focus();
                return;
            }
            if (txtNewPassword.Text != txtRepeatPassword.Text)
            {
                UiHelper.Warn("Пароли не совпадают.");
                txtRepeatPassword.Focus();
                return;
            }

            string error;
            if (!DataStore.ChangePassword(_user.Login, txtOldPassword.Text, txtNewPassword.Text, out error))
            {
                UiHelper.Warn(error);
                return;
            }

            UiHelper.Info("Пароль успешно изменён.");
            DialogResult = DialogResult.OK;
        }
    }
}
