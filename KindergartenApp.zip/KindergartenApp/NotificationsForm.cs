﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KindergartenApp
{
    public partial class NotificationsForm : Form
    {
        public NotificationsForm()
        {
            InitializeComponent();
            lstNotifications.HorizontalScrollbar = true;
            LoadNotifications();
        }
        private void LoadNotifications()
        {
            lstNotifications.Items.Clear();

            List<string> all = DataStore.GetNotifications();
            if (all.Count == 0)
            {
                lstNotifications.Items.Add("Уведомлений нет.");
                return;
            }

            for (int i = all.Count - 1; i >= 0; i--)
            {
                string[] lines = all[i].Replace("\r", "").Split('\n');
                foreach (string line in lines)
                    lstNotifications.Items.Add(line);
                lstNotifications.Items.Add("");
            }
        }
    }
}
